#pragma once
#include "GameState.h"
class HighScore :
	public GameState
{
};

